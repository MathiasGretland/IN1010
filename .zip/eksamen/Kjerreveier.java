
public class Kjerreveier extends Sti{
    Kjerreveier(int lengde, Kryss fra, Kryss til) {
        super(lengde, fra, til);
    }
}
