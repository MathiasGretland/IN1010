
public class Naturstier extends Sti{
    Naturstier(int lengde, Kryss fra, Kryss til) {
        super(lengde, fra, til);
    }
}
