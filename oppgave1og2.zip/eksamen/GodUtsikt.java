
public interface GodUtsikt {
    int hentUtsiktsverdi();
}
